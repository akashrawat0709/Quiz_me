# Online Quiz App with Firebase

#UI


![Screenshot_2023-12-18_at_14 21 54-removebg-preview](https://github.com/bimalkaf/Android_QuizAppWithFirebase/assets/60041910/53b13a70-6087-409f-894d-c749f6f7d976)



#HOMEPAGE
![Screenshot 2023-12-18 at 14 24 56](https://github.com/bimalkaf/Android_QuizAppWithFirebase/assets/60041910/9986de9f-5cec-4ca0-8d13-962c11db2a5e)



#QUIZ PAGE

![Screenshot 2023-12-18 at 14 25 14](https://github.com/bimalkaf/Android_QuizAppWithFirebase/assets/60041910/d22f0d62-83ba-42a9-a7c3-4c19bd1e183a)
